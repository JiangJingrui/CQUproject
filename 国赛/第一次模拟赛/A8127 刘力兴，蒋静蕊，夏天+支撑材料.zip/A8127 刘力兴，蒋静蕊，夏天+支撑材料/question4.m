clear
syms H;
% 网格数量
N = 50;

% 初始化参数
t_steps = 18000;% 在水中的时间步数
dt = 0.1; % 时间步长
K1 = 0.5804; % 瓜皮的导热系数
K2 = 0.4752; % 瓜瓤的导热系数
K3 = 0.02475; % 冰箱内空气的导热系数
K4 = 0.02742; % 外界空气的导热系数
K5 = 0.609; % 25度水的导热系数
C1 = 5257.6; % 瓜皮的比热
C2 = 3990.4; % 瓜瓤的比热
C3 = 1005; % 冰箱内空气的比热
C4 = 1005; % 外界空气的的比热
C5 = 4.179; % 25度水的比热
T1 = 38; % 瓜皮的温度
T2 = 38; % 瓜瓤的温度
T3 = 5; % 冰箱内空气的温度
T4 = 38; % 外界空气的的温度
T5 = 25; % 25度水的温度
P1 = 843.35; % 瓜皮的密度
P2 = 918.2; % 瓜瓤的密度
P3 = 1.27; % 冰箱内空气的密度
P4 = 1.1354; % 外界空气的密度
P5 = 997; % 25度水的密度
r1 = 15; % 西瓜半径
r2 = 13; % 瓜瓤半径
d = 0.01; % 散点距离
l1 = 15; % 空气的对流传热系数
l2 = 600; % 水的对流传热系数
% 初始化网格
T = zeros(N, N, N); % 温度
C = ones(N, N, N); % 比热
P = ones(N, N, N); % 密度
K = ones(N, N, N); % 导热
A = ones(N, N, N);
B = zeros(N, N, N);
% 初始条件
P0 = P1 + (P2-P1)*(r2/r1)^3;
V0 = pi*4/3*r1^3;
Vx = (P0-P4)/(P5-P4)*V0;
% 球冠高度求解式
f(H) = pi*(H^2)*(3*r1 - H)/3 == V0-Vx & r1>H & H>0;
h = vpa(solve(f(H),H)); % 求解球冠高度
h = double(h);
T(:,:,:) = T3;
% 判断点的位置
for i = 1:50
    for j = 1:50
        for k = 1:50
            RR = (i - 25.5)^2 + (j - 25.5)^2 + (k - 25.5-h+r1)^2;
            if sqrt(RR) <= 13 % 判断点的位置关系
                K(i,j,k) = K2; % 是瓜瓤的导热系数
                T(i,j,k) = T2; % 瓜瓤的温度
                C(i,j,k) = C2; % 瓜瓤的比热
                P(i,j,k) = P2; % 瓜瓤密度
                B(i,j,k) = 1;
            elseif sqrt(RR) <=15 % 瓜皮
                K(i,j,k) = K1; % 瓜皮的导热系数
                T(i,j,k) = T1; % 瓜皮的温度
                C(i,j,k) = C1; % 瓜皮的比热
                P(i,j,k) = P1; % 瓜皮密度
                B(i,j,k) = 1;
            elseif  k>25 % 空气
                K(i,j,k) = K4+l1*d; % 空气的等效导热系数
                T(i,j,k) = T4; % 空气的温度
                A(i,j,k) = 0;

            else  % 水
                K(i,j,k) = K5+l2*d; % 水的等效导热系数
                T(i,j,k) = T5; % 水的温度
                C(i,j,k) = C2; % 水的比热
                P(i,j,k) = P2; % 水密度
            end  
        end
    end
end


% 有限差分法
for t = 1:t_steps

    for i = 2:49
        for j = 2:49
            for k = 2:49
                q(i,j,k) = ((K(i + 1, j, k) + K(i, j, k)) * (T(i + 1, j, k) - T(i, j, k)) + ...
                    (K(i - 1, j, k) + K(i, j, k)) * (T(i - 1, j, k) - T(i, j, k)) + ...
                    (K(i, j + 1, k) + K(i, j, k)) * (T(i, j + 1, k) - T(i, j, k)) + ...
                    (K(i, j - 1, k) + K(i, j, k)) * (T(i, j - 1, k) - T(i, j, k)) + ...
                    (K(i, j, k + 1) + K(i, j, k)) * (T(i, j, k + 1) - T(i, j, k)) + ...
                    (K(i, j, k - 1) + K(i, j, k)) * (T(i, j, k - 1) - T(i, j, k))) / (2 * d);
                T(i, j, k) = T(i, j, k) + A(i,j,k)*q(i,j,k) * dt / (C(i, j, k)*d*P(i,j,k));
            end
        end
    end
end




N=32;
G=ones(N,N,N);
%转换
for i = 1:50
    for j = 1:50
        for k = 1:50
            RR = (i - 25.5)^2 + (j - 25.5)^2 + (k - 25.5-h+r1)^2;
            if sqrt(RR) <= 15 % 判断点的位置关系
               G(i-9,j-9,k)=T(i,j,k);
            end  
        end
    end
end




Y=ones(N,N,17);
%转换
for i = 1:32
    for j = 1:16
        for k = 1:32
               Y(i,k,j)=G(i,j,k);
        end  
    end
end




% 初始条件
T = Y;
% 判断点的位置
for i = 1:32
    for j = 1:32
        for k = 1:16
            RR = (i - 16.5)^2 + (j - 16.5)^2 + (k - 16.5)^2;
            if sqrt(RR) <= 13 % 判断点的位置关系
                K(i,j,k) = K2; % 是瓜瓤的导热系数
                C(i,j,k) = C2; % 瓜瓤的比热
                P(i,j,k) = P2; % 瓜瓤密度
            elseif sqrt(RR) <=15 % 瓜皮
                K(i,j,k) = K1; % 是瓜皮的导热系数
                C(i,j,k) = C1; % 是瓜皮的比热
                P(i,j,k) = P1; % 瓜皮密度
            elseif sqrt(RR) <=16 % 瓜皮表面空气
                K(i,j,k) = K3; % 是空气和西瓜之间的等效导热系数
                A(i,j,k) = 0;
            else
                A(i,j,k) = 0;
            end  
        end
    end
end
                K(:,:,17) = K3; % 空气的等效导热系数
                A(:,:,17) = 0;
                T(:,:,17) = 5;




% 有限差分法
for t = 1:1000000

    for i = 2:31
        for j = 2:31
            for k = 2:16
                q(i,j,k) = ((K(i + 1, j, k) + K(i, j, k)) * (T(i + 1, j, k) - T(i, j, k)) + ...
                    (K(i - 1, j, k) + K(i, j, k)) * (T(i - 1, j, k) - T(i, j, k)) + ...
                    (K(i, j + 1, k) + K(i, j, k)) * (T(i, j + 1, k) - T(i, j, k)) + ...
                    (K(i, j - 1, k) + K(i, j, k)) * (T(i, j - 1, k) - T(i, j, k)) + ...
                    (K(i, j, k + 1) + K(i, j, k)) * (T(i, j, k + 1) - T(i, j, k)) + ...
                    (K(i, j, k - 1) + K(i, j, k)) * (T(i, j, k - 1) - T(i, j, k))) / (2 * d);
                T(i, j, k) = T(i, j, k) + A(i,j,k)*q(i,j,k) * dt / (C(i, j, k)*d*P(i,j,k));
            end
        end
    end
    temperature(t) = max(max(max(T)));
    o=temperature(t);
    if o<=10
        break;
    end
end


% 绘制指定点的温度随时间的变化曲线
time = (1:t) * dt;
plot(time, temperature, 'r')
xlabel('时间')
ylabel('温度')
%t_steps,总时间记录
t_all=[1 4500 9000 13500 18000;239407 241702 245202 248886 253667];
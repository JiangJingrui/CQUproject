clear
%Newton插值法拟合函数并通过取节点来找极值：
W = [1 4500 9000 13500 18000;474255	475787	478786	482007	485347];%前面得到的矩阵
X = W(1,:);
f = W(2,:);
U = f;
f = f';

%求各阶均差
for i=1:4
for j=1:i
f(i+1,j+1)=(f(i,j)-f(i+1,j))/(X(i-j+1)-X(i+1));
end
end


for k=1:10000
    x(k)=1.8*k;
    N(1)=f(1,1);
for i=2:5
P(i)=1;
for j=1:i-1
P(i)=P(i)*(x(k)-X(j));
end 
N(i)=N(i-1)+f(i,i)*P(i) ;
end
fx(k)=N(5);
end

figure(1); %拟合函数图像
plot(x,fx)
mi=min(fx)
ni=find(fx==min(fx))
xlabel('水浴预冷时间')
ylabel('总预冷时间')
title('整个西瓜预冷拟合函数')
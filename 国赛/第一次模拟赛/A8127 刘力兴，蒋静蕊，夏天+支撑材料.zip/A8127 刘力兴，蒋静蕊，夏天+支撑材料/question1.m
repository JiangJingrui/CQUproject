
clear
% 网格数量
N = 32;

% 初始化参数
dt = 0.1; % 时间步长
K1 = 0.5804; % 瓜皮的导热系数
K2 = 0.4752; % 瓜瓤的导热系数
K3 = 0.02475; % 冰箱内空气的导热系数
K4 = 0.02742; % 外界空气的导热系数
K5 = 0.609; % 25度水的导热系数
C1 = 5257.6; % 瓜皮的比热
C2 = 3990.4; % 瓜瓤的比热
C3 = 1005; % 冰箱内空气的比热
C4 = 1005; % 外界空气的的比热
C5 = 4.179; % 25度水的比热
T1 = 38; % 瓜皮的温度
T2 = 38; % 瓜瓤的温度
T3 = 5; % 冰箱内空气的温度
T4 = 38; % 外界空气的的温度
T5 = 25; % 25度水的温度
P1 = 843.35; % 瓜皮的密度
P2 = 918.2; % 瓜瓤的密度
P3 = 1.27; % 冰箱内空气的密度
P4 = 1.1354; % 外界空气的密度
P5 = 997; % 25度水的密度
r1 = 15; % 西瓜半径
r2 = 13; % 瓜瓤半径
d = 0.01; % 散点距离
l1 = 15; % 空气的对流传热系数
l2 = 600; % 水的对流传热系数
% 初始化网格
T = zeros(N, N, N); % 温度
C = ones(N, N, N); % 比热
P = ones(N, N, N); % 密度
K = ones(N, N, N); % 导热
A = ones(N, N, N);
% 初始条件

T(:,:,:) = T3;
% 判断点的位置
for i = 1:32
    for j = 1:32
        for k = 1:32
            RR = (i - 16.5)^2 + (j - 16.5)^2 + (k - 16.5)^2;
            if sqrt(RR) <= 13 % 判断点的位置关系
                K(i,j,k) = K2; % 是瓜瓤的导热系数
                T(i,j,k) = T2; % 瓜瓤的温度
                C(i,j,k) = C2; % 瓜瓤的比热
                P(i,j,k) = P2; % 瓜瓤密度
            elseif sqrt(RR) <=15 % 瓜皮
                K(i,j,k) = K1; % 是瓜皮的导热系数
                T(i,j,k) = T1; % 是瓜皮的温度
                C(i,j,k) = C1; % 是瓜皮的比热
                P(i,j,k) = P1; % 瓜皮密度
            elseif sqrt(RR) <=16 % 瓜皮表面空气
                K(i,j,k) = K3+l1*d; % 是空气和西瓜之间的等效导热系数
                A(i,j,k) = 0;
            else
                A(i,j,k) = 0;
            end  
        end
    end
end

% 时间步数
t_steps = 300000;



% 有限差分法
for t = 1:t_steps

    for i = 2:31
        for j = 2:31
            for k = 2:31
                q(i,j,k) = ((K(i + 1, j, k) + K(i, j, k)) * (T(i + 1, j, k) - T(i, j, k)) + ...
                    (K(i - 1, j, k) + K(i, j, k)) * (T(i - 1, j, k) - T(i, j, k)) + ...
                    (K(i, j + 1, k) + K(i, j, k)) * (T(i, j + 1, k) - T(i, j, k)) + ...
                    (K(i, j - 1, k) + K(i, j, k)) * (T(i, j - 1, k) - T(i, j, k)) + ...
                    (K(i, j, k + 1) + K(i, j, k)) * (T(i, j, k + 1) - T(i, j, k)) + ...
                    (K(i, j, k - 1) + K(i, j, k)) * (T(i, j, k - 1) - T(i, j, k))) / (2 * d);
                T(i, j, k) = T(i, j, k) + A(i,j,k)*q(i,j,k) * dt / (C(i, j, k)*d*P(i,j,k));
            end
        end
    end
    temperature1(t) = T(16, 16, 16);
    temperature2(t) = T(16, 16, 9);
end


% 绘制指定点的温度随时间的变化曲线
figure(1); %中点温度随时间的变化
time = (1:t_steps) * dt;
plot(time, temperature1, 'r')
xlabel('时间/s')
ylabel('温度/℃')
title('西瓜中点温度随时间的变化')


figure(2); %中点附近的点随时间的变化
time = (1:t_steps) * dt;
plot(time, temperature2, 'r')
xlabel('时间/s')
ylabel('温度/℃')
title('西瓜中点附近的点温度随时间的变化')


figure(3); %温度彩色图
E=squeeze(T(16,:,:));
[x_vals, y_vals] = ind2sub([ N, N], find(E(:)));
colors = E(E > -100);
scatter(x_vals, y_vals, N, colors, 'filled');
colorbar;
ylabel(colorbar,'T','FontSize',14,'FontName','Times New Roman','FontWeight','bold')
xlabel('X');
ylabel('Y');
title('温度彩色图');
